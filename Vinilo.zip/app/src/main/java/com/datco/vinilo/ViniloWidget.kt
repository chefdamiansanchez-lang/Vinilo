package com.datco.vinilo

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class ViniloWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        render(context, appWidgetManager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (!PlayerHolder.isReady) return
        val p = PlayerHolder.player
        when (intent.action) {
            ACTION_PLAY -> {
                if (p.isPlaying) {
                    p.pause()
                } else if (p.mediaItemCount > 0) {
                    p.play()
                    try {
                        context.startService(Intent(context, PlayerService::class.java))
                    } catch (e: Exception) { }
                }
            }
            ACTION_NEXT -> p.seekToNext()
            ACTION_PREV -> p.seekToPrevious()
        }
    }

    companion object {
        const val ACTION_PLAY = "com.datco.vinilo.WIDGET_PLAY"
        const val ACTION_NEXT = "com.datco.vinilo.WIDGET_NEXT"
        const val ACTION_PREV = "com.datco.vinilo.WIDGET_PREV"

        fun update(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, ViniloWidget::class.java))
            if (ids.isNotEmpty()) render(context, mgr, ids)
        }

        private fun action(context: Context, action: String): PendingIntent =
            PendingIntent.getBroadcast(
                context, action.hashCode(),
                Intent(context, ViniloWidget::class.java).setAction(action),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        private fun render(context: Context, mgr: AppWidgetManager, ids: IntArray) {
            if (!PlayerHolder.isReady) return
            val p = PlayerHolder.player
            val md = p.mediaMetadata
            val rv = RemoteViews(context.packageName, R.layout.widget)
            rv.setTextViewText(R.id.w_title, md.title ?: "Vinilo")
            rv.setTextViewText(R.id.w_artist, md.artist ?: "Tocá para abrir")
            rv.setImageViewResource(R.id.w_play, if (p.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            rv.setOnClickPendingIntent(R.id.w_play, action(context, ACTION_PLAY))
            rv.setOnClickPendingIntent(R.id.w_next, action(context, ACTION_NEXT))
            rv.setOnClickPendingIntent(R.id.w_prev, action(context, ACTION_PREV))
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.w_root, open)
            mgr.updateAppWidget(ids, rv)
        }
    }
}

package com.datco.vinilo

import android.app.Application

class ViniloApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PlayerHolder.init(this)
    }
}

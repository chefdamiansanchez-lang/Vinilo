package com.datco.vinilo

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ViniloTheme { Root() } }
    }

    override fun onStop() {
        super.onStop()
        PlayerHolder.saveProgress()
    }
}

val Orange = Color(0xFFE07B39)

@Composable
fun ViniloTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Orange,
            onPrimary = Color.Black,
            secondary = Color(0xFF9DB7E8),
            background = Color(0xFF14161B),
            surface = Color(0xFF1B2028),
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

sealed class Screen {
    object Player : Screen()
    object Library : Screen()
    object Eq : Screen()
    data class Detail(val id: Long) : Screen()
}

fun requiredPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) {
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

fun hasAudioPermission(ctx: Context): Boolean {
    val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
}

@Composable
fun Root() {
    var showSplash by rememberSaveable { mutableStateOf(true) }
    if (showSplash) SplashScreen { showSplash = false } else AppContent()
}

@Composable
fun AppContent(vm: PlayerViewModel = viewModel()) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPermission(ctx)
        if (granted) vm.loadSongs()
    }
    val request: () -> Unit = { launcher.launch(requiredPermissions()) }

    LaunchedEffect(Unit) {
        if (granted) vm.loadSongs() else request()
    }

    var screen by remember { mutableStateOf<Screen>(Screen.Player) }
    var tab by rememberSaveable { mutableStateOf(0) }

    BackHandler(enabled = screen != Screen.Player) {
        screen = if (screen is Screen.Detail) Screen.Library else Screen.Player
    }

    when (val s = screen) {
        Screen.Player -> PlayerScreen(
            vm,
            onLibrary = { screen = Screen.Library },
            onEq = { screen = Screen.Eq }
        )
        Screen.Library -> LibraryScreen(
            vm, tab, { tab = it }, granted, request,
            onOpenPlaylist = { screen = Screen.Detail(it) },
            onBack = { screen = Screen.Player }
        )
        Screen.Eq -> EqScreen(vm) { screen = Screen.Player }
        is Screen.Detail -> PlaylistDetailScreen(
            vm, s.id,
            onBack = { screen = Screen.Library },
            onPlayed = { screen = Screen.Player }
        )
    }
}

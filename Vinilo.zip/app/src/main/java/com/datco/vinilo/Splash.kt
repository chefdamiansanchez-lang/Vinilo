package com.datco.vinilo

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Splash de DATCO que abre la app. */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val fade = remember { Animatable(0f) }
    val grow = remember { Animatable(0.8f) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { fade.animateTo(1f, tween(800)) }
            launch { grow.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 200f)) }
        }
        delay(1500)
        onDone()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFF1B2028)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .graphicsLayer {
                    this.alpha = fade.value
                    scaleX = grow.value
                    scaleY = grow.value
                }
                .padding(32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(104.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))),
                contentAlignment = Alignment.Center
            ) {
                Text("D", color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(24.dp))
            Text(
                "DATCO",
                color = Color.White,
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías y Códigos Operativos",
                color = Color(0xFF8FA3B8),
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
        Text(
            "Diseño de apps... y algo más",
            color = Color(0xFF8FA3B8),
            fontSize = 13.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp)
                .graphicsLayer { this.alpha = fade.value }
        )
    }
}

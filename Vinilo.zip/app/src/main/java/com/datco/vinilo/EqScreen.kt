@file:OptIn(ExperimentalMaterial3Api::class)

package com.datco.vinilo

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun EqScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    LaunchedEffect(Unit) { vm.initEq() }
    val fx = vm.fx

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ecualizador") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            if (!fx.available) {
                Text("Este teléfono no permite ecualizar. Reproducí una canción y volvé a entrar.")
                Spacer(Modifier.height(12.dp))
            }

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Activar ecualizador", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Switch(checked = vm.eqEnabled, onCheckedChange = { vm.toggleEq(it) })
            }

            val presets = fx.presetNames()
            if (presets.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("Preajustes", fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presets.forEachIndexed { i, name ->
                        FilterChip(
                            selected = false,
                            onClick = { vm.applyPreset(i) },
                            label = { Text(name) }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            vm.bandLevels.forEachIndexed { i, level ->
                val f = fx.freqHz(i)
                val label = if (f >= 1000) "${(f / 100) / 10f} kHz" else "$f Hz"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(label, fontSize = 14.sp)
                    Text("%.1f dB".format(level / 100f), fontSize = 14.sp, color = MaterialTheme.colorScheme.secondary)
                }
                Slider(
                    value = level.toFloat(),
                    onValueChange = { vm.setBand(i, it.roundToInt()) },
                    valueRange = fx.minLevel.toFloat()..fx.maxLevel.toFloat()
                )
            }

            Spacer(Modifier.height(12.dp))
            Text("Bajos (Bass)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Slider(
                value = vm.bass.toFloat(),
                onValueChange = { vm.updateBass(it.roundToInt()) },
                valueRange = 0f..1000f
            )
            Text("Virtualizador (sonido envolvente)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Slider(
                value = vm.virt.toFloat(),
                onValueChange = { vm.updateVirt(it.roundToInt()) },
                valueRange = 0f..1000f
            )
        }
    }
}
